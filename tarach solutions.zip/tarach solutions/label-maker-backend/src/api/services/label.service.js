const Label = require('../models/label.model');
const User = require('../models/user.model');
const Counter = require('../models/counter.model');
const { ApiError } = require('../middleware/error.middleware');
const mongoose = require('mongoose');

class LabelService {
  async getNextLabelId() {
    const counter = await Counter.findByIdAndUpdate(
      { _id: 'labelId' },
      { $inc: { seq: 1 } },
      { new: true, upsert: true }
    );
    return counter.seq;
  }

  async createLabel(labelData, userId) {
    try {
      console.log('Service userId:', userId);
      
      if (!userId) {
        throw new ApiError(400, 'User ID is required');
      }

      const user = await User.findOne({ userId: userId })
        .select('firstName lastName email userId')
        .lean();

      if (!user) {
        throw new ApiError(404, 'User not found');
      }

      const labelId = await this.getNextLabelId();

      const label = new Label({
        labelId: labelId,
        title: labelData.title,
        content: labelData.content,
        createdBy: userId,
        createdDate: new Date()
      });

      const savedLabel = await label.save();
      
      const responseLabel = {
        ...savedLabel.toObject(),
        createdBy: user
      };

      return responseLabel;
    } catch (error) {
      console.error('Error in createLabel:', error);
      throw new ApiError(500, error.message);
    }
  }

  async findLabelByTitle(title, userId) {
    return await Label.findOne({ 
      title, 
      createdBy: userId,
      isDeleted: false 
    });
  }

  async getLabelByLabelId(labelId, userId) {
    const label = await Label.findOne({
      labelId: labelId,
      createdBy: userId,
      isDeleted: false
    });
    
    if (!label) {
      throw new ApiError(404, 'Label not found');
    }
    
    return label;
  }

  async updateLabel(labelId, updateData, userId) {
    try {
      // Get user data first
      const user = await User.findOne({ userId: userId })
        .select('firstName lastName email userId')
        .lean();

      if (!user) {
        throw new ApiError(404, 'User not found');
      }

      // Get the label - removed createdBy condition
      const label = await Label.findOne({
        labelId: labelId,
        isDeleted: false
      });

      if (!label) {
        throw new ApiError(404, 'Label not found');
      }

      // Check for title conflict if title is being updated
      if (updateData.title && updateData.title !== label.title) {
        const existingLabel = await this.findLabelByTitle(updateData.title, userId);
        if (existingLabel) {
          throw new ApiError(409, 'A label with this title already exists');
        }
      }

      // Update the label
      const updatedLabel = await Label.findOneAndUpdate(
        { labelId: labelId },
        {
          $set: {
            ...(updateData.title && { title: updateData.title }),
            ...(updateData.content && { content: updateData.content }),
            updatedBy: userId,
            updatedDate: new Date()
          }
        },
        { 
          new: true,
          runValidators: true
        }
      ).lean();

      // Add user data to response
      const responseLabel = {
        ...updatedLabel,
        createdBy: user,
        updatedBy: user
      };

      return responseLabel;
    } catch (error) {
      console.error('Error in updateLabel:', error);
      throw new ApiError(500, error.message || 'Error updating label');
    }
  }

  async deleteLabel(labelId, userId) {
    try {
      console.log('Deleting label:', { labelId, userId, labelIdType: typeof labelId });

      // Get user data first
      const user = await User.findOne({ userId: userId })
        .select('firstName lastName email userId')
        .lean();

      if (!user) {
        throw new ApiError(404, 'User not found');
      }

      // Get the label - ensure labelId is treated as number
      const label = await Label.findOne({
        labelId: parseInt(labelId),
        isDeleted: false
      });

      console.log('Label search criteria:', { 
        labelId: parseInt(labelId), 
        parsedValue: parseInt(labelId),
        isDeleted: false 
      });
      console.log('Found label:', label);

      if (!label) {
        throw new ApiError(404, 'Label not found');
      }

      // Soft delete the label
      const deletedLabel = await Label.findOneAndUpdate(
        { labelId: parseInt(labelId) },
        {
          $set: {
            isDeleted: true,
            updatedBy: userId,
            updatedDate: new Date()
          }
        },
        { new: true }
      ).lean();

      // Add user data to response
      const responseLabel = {
        ...deletedLabel,
        createdBy: user,
        updatedBy: deletedLabel.updatedBy ? user : undefined
      };

      return responseLabel;
    } catch (error) {
      console.error('Error in deleteLabel:', error);
      throw new ApiError(500, error.message || 'Error deleting label');
    }
  }

  async restoreLabel(labelId, userId) {
    console.log('Restoring label:', {
      labelId,
      labelIdType: typeof labelId,
      parsedLabelId: parseInt(labelId),
      userId
    });
    
    // First check if any label exists with this ID, regardless of status
    const allLabels = await Label.find({}).lean();
    console.log('All labels in DB:', allLabels.map(l => ({
      labelId: l.labelId,
      isDeleted: l.isDeleted,
      title: l.title
    })));

    const anyLabel = await Label.findOne({ 
      labelId: parseInt(labelId)
    });
    
    console.log('Label exists check:', {
      searchLabelId: parseInt(labelId),
      labelFound: !!anyLabel,
      labelDetails: anyLabel,
      isDeleted: anyLabel?.isDeleted,
      createdBy: anyLabel?.createdBy
    });

    if (!anyLabel) {
      throw new ApiError(404, 'Label not found');
    }

    if (!anyLabel.isDeleted) {
      throw new ApiError(400, 'Label is not deleted');
    }

    // Restore the label using only standard fields
    const restoredLabel = await Label.findOneAndUpdate(
      { labelId: parseInt(labelId) },
      {
        $set: {
          isDeleted: false,
          updatedBy: userId,
          updatedDate: new Date()
        }
      },
      { new: true }
    ).lean();

    // Get user data
    const user = await User.findOne({ userId: userId })
      .select('firstName lastName email userId')
      .lean();

    // Add user data to response
    const responseLabel = {
      ...restoredLabel,
      createdBy: user,
      updatedBy: user
    };

    return responseLabel;
  }

  async searchLabels(searchParams, userId) {
    const { 
      title = '', 
      page = 1, 
      limit = 10 
    } = searchParams;

    // Build search query
    const query = {
      isDeleted: false
    };

    // Add title search if provided
    if (title) {
      query.title = {
        $regex: title,
        $options: 'i'
      };
    }

    const skip = (page - 1) * limit;

    // Get the labels without population first
    const [labels, total] = await Promise.all([
      Label.find(query)
        .sort({ createdDate: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      Label.countDocuments(query)
    ]);

    // Get all unique userIds from the labels
    const userIds = [...new Set([
      ...labels.map(label => label.createdBy),
      ...labels.map(label => label.updatedBy).filter(Boolean)
    ])];

    // Fetch all relevant users in one query
    const users = await User.find({ userId: { $in: userIds } })
      .select('firstName lastName email userId')
      .lean();

    // Create a map of userId to user object for quick lookup
    const userMap = users.reduce((acc, user) => {
      acc[user.userId] = user;
      return acc;
    }, {});

    // Add user data to labels
    const labelsWithUsers = labels.map(label => ({
      ...label,
      createdBy: userMap[label.createdBy] || null,
      updatedBy: label.updatedBy ? userMap[label.updatedBy] || null : undefined
    }));

    const totalPages = Math.ceil(total / limit);
    const hasNext = page < totalPages;
    const hasPrev = page > 1;

    return {
      labels: labelsWithUsers,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages,
        hasNext,
        hasPrev
      }
    };
  }

  async getLabels(params, userId) {
    try {
      const { 
        page = 1, 
        limit = 10,
        sortBy = 'createdDate',
        sortOrder = 'desc'
      } = params;

      const query = {
        isDeleted: false
      };

      const skip = (page - 1) * limit;
      const sort = {
        [sortBy]: sortOrder === 'desc' ? -1 : 1
      };

      // Get user data first
      const user = await User.findOne({ userId: userId })
        .select('firstName lastName email userId')
        .lean();

      if (!user) {
        throw new ApiError(404, 'User not found');
      }

      // Execute query with specific field selection
      const [labels, total] = await Promise.all([
        Label.find(query)
          .select('labelId title createdBy createdDate updatedDate updatedBy')
          .sort(sort)
          .skip(skip)
          .limit(limit)
          .lean(),
        Label.countDocuments(query)
      ]);

      // Add user data to each label with only required fields
      const labelsWithUser = labels.map(label => ({
        labelId: label.labelId,
        title: label.title,
        createdBy: user,
        createdDate: label.createdDate,
        updatedDate: label.updatedDate,
        updatedBy: label.updatedBy ? user : undefined
      }));

      return {
        labels: labelsWithUser,
        pagination: {
          total,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(total / limit),
          hasNext: page < Math.ceil(total / limit),
          hasPrev: page > 1
        }
      };
    } catch (error) {
      console.error('Error in getLabels:', error);
      throw new ApiError(500, 'Error retrieving labels');
    }
  }

  async getLabelDetails(labelId, userId) {
    try {
      // Get user data first
      const user = await User.findOne({ userId: userId })
        .select('firstName lastName email userId')
        .lean();

      if (!user) {
        throw new ApiError(404, 'User not found');
      }

      // Get the label
      const label = await Label.findOne({
        labelId: parseInt(labelId),
        isDeleted: false
      }).lean();

      if (!label) {
        throw new ApiError(404, 'Label not found');
      }

      // Add user data to response
      const responseLabel = {
        ...label,
        createdBy: user,
        updatedBy: label.updatedBy ? user : undefined
      };

      return responseLabel;
    } catch (error) {
      console.error('Error in getLabelDetails:', error);
      throw new ApiError(500, error.message || 'Error retrieving label details');
    }
  }
}

module.exports = new LabelService(); 