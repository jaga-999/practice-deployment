const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { ApiError } = require('../middleware/error.middleware');
const Token = require('../models/token.model');
const User = require('../models/user.model');

class AuthService {
  constructor() {
    this.JWT_ACCESS_SECRET = process.env.JWT_ACCESS_SECRET || 'your-very-secure-access-secret-key-2024';
    this.JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'your-very-secure-refresh-secret-key-2024';
  }

  async login(email, password, req, res) {
    try {
      const user = await User.findOne({ email });
      if (!user) {
        throw new ApiError(401, 'Invalid credentials');
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        throw new ApiError(401, 'Invalid credentials');
      }

      const tokens = this.generateTokens(user.userId);
      await this.saveToken(user.userId, tokens, req);

      res.cookie('accessToken', tokens.accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 60 * 60 * 1000,
        path: '/'
      });

      res.cookie('refreshToken', tokens.refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: '/'
      });

      const { password: _, ...userWithoutPassword } = user.toObject();
      return {
        user: userWithoutPassword
      };
    } catch (error) {
      console.error('Login error:', error);
      if (error instanceof ApiError) throw error;
      throw new ApiError(500, 'Login failed');
    }
  }

  async verifyAndRefreshTokens(req, res) {
    try {
      const accessToken = req.cookies.accessToken;
      const refreshToken = req.cookies.refreshToken;

      if (!refreshToken) {
        throw new ApiError(401, 'Refresh token is required');
      }

      const refreshDecoded = jwt.verify(refreshToken, this.JWT_REFRESH_SECRET);

      const tokenDoc = await Token.findOne({
        userId: refreshDecoded.userId,
        refreshToken,
        isValid: true
      });

      if (!tokenDoc) {
        throw new ApiError(401, 'Token not found or invalidated');
      }

      const user = await User.findOne({ userId: refreshDecoded.userId });
      if (!user) {
        throw new ApiError(404, 'User not found');
      }

      if (!accessToken) {
        const newTokens = this.generateTokens(refreshDecoded.userId);

        res.cookie('accessToken', newTokens.accessToken, {
          httpOnly: true,
          secure: process.env.NODE_ENV === 'production',
          sameSite: 'strict',
          maxAge: 60 * 60 * 1000,
          path: '/'
        });

        await Token.updateOne(
          { _id: tokenDoc._id },
          {
            accessToken: newTokens.accessToken,
            accessTokenExpiresAt: newTokens.accessTokenExpiresAt
          }
        );
      }

      const { password: _, ...userWithoutPassword } = user.toObject();
      
      return {
        userId: refreshDecoded.userId,
        user: userWithoutPassword
      };

    } catch (error) {
      if (error instanceof ApiError) throw error;
      throw new ApiError(401, 'Invalid token');
    }
  }

  generateTokens(userId) {
    const accessToken = jwt.sign(
      { userId },
      this.JWT_ACCESS_SECRET,
      { expiresIn: '1h' }
    );

    const refreshToken = jwt.sign(
      { userId },
      this.JWT_REFRESH_SECRET,
      { expiresIn: '7d' }
    );

    return {
      accessToken,
      refreshToken,
      accessTokenExpiresAt: new Date(Date.now() + 60 * 60 * 1000),
      refreshTokenExpiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    };
  }

  async saveToken(userId, tokens, req) {
    try {
      await Token.updateMany(
        {
          userId,
          deviceInfo: req.headers['user-agent'] || 'unknown',
          isValid: true
        },
        { isValid: false }
      );

      const tokenRecord = new Token({
        userId,
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        accessTokenExpiresAt: tokens.accessTokenExpiresAt,
        refreshTokenExpiresAt: tokens.refreshTokenExpiresAt,
        deviceInfo: req.headers['user-agent'] || 'unknown',
        ipAddress: req.ip || req.connection.remoteAddress,
        isValid: true
      });

      return await tokenRecord.save();
    } catch (error) {
      throw new ApiError(500, 'Error saving token');
    }
  }

  async logout(req, res) {
    try {
      const refreshToken = req.cookies.refreshToken;
      
      if (!refreshToken) {
        throw new ApiError(400, 'Refresh token is required');
      }

      await Token.updateOne(
        { refreshToken, isValid: true },
        { isValid: false }
      );

      res.clearCookie('accessToken', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        path: '/'
      });
      
      res.clearCookie('refreshToken', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        path: '/'
      });

      return true;
    } catch (error) {
      if (error instanceof ApiError) throw error;
      throw new ApiError(500, 'Logout failed');
    }
  }
}

module.exports = new AuthService(); 