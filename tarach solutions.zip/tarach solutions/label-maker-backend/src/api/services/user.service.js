const User = require('../models/user.model');
const Counter = require('../models/counter.model');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { ApiError } = require('../middleware/error.middleware');

class UserService {
  async getNextUserId() {
    const counter = await Counter.findByIdAndUpdate(
      { _id: 'userId' },
      { $inc: { seq: 1 } },
      { new: true, upsert: true }
    );
    return `USER${counter.seq.toString().padStart(6, '0')}`;
  }

  async createUser(userData) {
    try {
      console.log('Creating user with data:', {
        ...userData,
        password: '[REDACTED]'  // Don't log passwords
      });

      // Validate required fields
      if (!userData.email || !userData.password || !userData.firstName || !userData.lastName) {
        throw new ApiError(400, 'All fields are required');
      }

      // Check if user already exists
      const existingUser = await User.findOne({ email: userData.email });
      if (existingUser) {
        throw new ApiError(409, 'User with this email already exists');
      }

      // Generate userId
      const userId = await this.getNextUserId();

      // Hash password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(userData.password, salt);

      // Create new user
      const user = new User({
        userId: userId,  // Add the generated userId
        firstName: userData.firstName,
        lastName: userData.lastName,
        email: userData.email.toLowerCase(),
        password: hashedPassword,
        createdDate: new Date()
      });

      console.log('Attempting to save user...');
      const savedUser = await user.save();
      console.log('User saved successfully');

      // Remove password from response
      const userResponse = savedUser.toObject();
      delete userResponse.password;

      return userResponse;
    } catch (error) {
      console.error('Error in createUser:', {
        message: error.message,
        stack: error.stack,
        code: error.code  // MongoDB error code if present
      });
      
      // Handle specific MongoDB errors
      if (error.code === 11000) {
        throw new ApiError(409, 'User with this email already exists');
      }
      
      throw new ApiError(500, `Error creating user: ${error.message}`);
    }
  }

  async findUserByEmail(email) {
    return await User.findOne({ email });
  }
}

module.exports = new UserService();
