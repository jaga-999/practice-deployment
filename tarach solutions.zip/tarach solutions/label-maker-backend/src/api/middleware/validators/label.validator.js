const { body, param, query } = require('express-validator');

const createLabelValidation = [
  body('title')
    .trim()
    .notEmpty()
    .withMessage('Title is required')
    .isLength({ max: 100 })
    .withMessage('Title must be less than 100 characters'),
  body('content')
    .notEmpty()
    .withMessage('Content is required')
    .isObject()
    .withMessage('Content must be a valid JSON object')
];

const updateLabelValidation = [
  body('labelId')
    .notEmpty()
    .withMessage('Label ID is required')
    .isInt({ min: 1 })
    .withMessage('Invalid label ID format'),
  body('title')
    .optional()
    .trim()
    .notEmpty()
    .withMessage('Title cannot be empty if provided')
    .isLength({ max: 100 })
    .withMessage('Title must be less than 100 characters'),
  body('content')
    .optional()
    .notEmpty()
    .withMessage('Content cannot be empty if provided')
    .isObject()
    .withMessage('Content must be a valid JSON object')
];

const deleteLabelValidation = [
  param('labelId')
    .notEmpty()
    .withMessage('Label ID is required')
    .isInt({ min: 1 })
    .withMessage('Invalid label ID format')
];

const searchLabelValidation = [
  query('title')
    .optional()
    .trim()
    .isLength({ min: 1 })
    .withMessage('Search term must not be empty'),
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100')
];

const getLabelsValidation = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100'),
  query('sortBy')
    .optional()
    .isIn(['createdDate', 'title', 'updatedDate'])
    .withMessage('Sort by must be one of: createdDate, title, updatedDate'),
  query('sortOrder')
    .optional()
    .isIn(['asc', 'desc'])
    .withMessage('Sort order must be either asc or desc')
];

const getLabelByIdValidation = [
  param('labelId')
    .notEmpty()
    .withMessage('Label ID is required')
    .isInt({ min: 1 })
    .withMessage('Invalid label ID format')
];

module.exports = {
  createLabelValidation,
  updateLabelValidation,
  deleteLabelValidation,
  searchLabelValidation,
  getLabelsValidation,
  getLabelByIdValidation
}; 