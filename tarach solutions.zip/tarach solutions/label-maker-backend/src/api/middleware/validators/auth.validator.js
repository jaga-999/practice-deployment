const { body } = require('express-validator');

const loginValidation = [
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please enter a valid email'),
  body('password')
    .notEmpty()
    .withMessage('Password is required')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long')
];

const logoutValidation = [
  // Remove validation since we're getting refreshToken from cookies
];

const verifyTokenValidation = [
  // Remove the previous validations since we're using cookies now
];

module.exports = {
  loginValidation,
  logoutValidation,
  verifyTokenValidation
}; 