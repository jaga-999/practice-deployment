const jwt = require('jsonwebtoken');
const Token = require('../models/token.model');
const { ApiError } = require('./error.middleware');

const authenticateToken = async (req, res, next) => {
  try {
    // Get token from cookie instead of Authorization header
    const token = req.cookies.accessToken;

    if (!token) {
      throw new ApiError(401, 'Access token is required');
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
    
    // Check if token exists and is valid in database
    const tokenRecord = await Token.findOne({
      userId: decoded.userId,
      accessToken: token,
      isValid: true
    });

    if (!tokenRecord) {
      throw new ApiError(401, 'Invalid token');
    }

    // Add user info to request
    req.user = {
      userId: decoded.userId
    };

    next();
  } catch (error) {
    console.error('Authentication error:', error);

    if (error.name === 'JsonWebTokenError') {
      return next(new ApiError(401, 'Invalid token'));
    }

    if (error.name === 'TokenExpiredError') {
      return next(new ApiError(401, 'Token expired'));
    }

    return next(new ApiError(500, 'An error occurred during authentication'));
  }
};

module.exports = {
  authenticateToken
};
