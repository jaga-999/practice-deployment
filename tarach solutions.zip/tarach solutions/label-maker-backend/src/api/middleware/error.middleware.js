const { ValidationError } = require('express-validator');
const mongoose = require('mongoose');

// Custom error class for API errors
class ApiError extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.status = 'error';
  }
}

// Error handling middleware
const errorHandler = (err, req, res, next) => {
  console.error('Error:', err);

  // Default error
  let error = {
    status: 'error',
    message: 'Internal Server Error',
    statusCode: 500
  };

  // Mongoose validation error
  if (err instanceof mongoose.Error.ValidationError) {
    error.statusCode = 400;
    error.message = Object.values(err.errors).map(e => e.message).join(', ');
  }

  // Mongoose duplicate key error
  if (err.code === 11000) {
    error.statusCode = 409;
    error.message = 'Duplicate value entered';
    const field = Object.keys(err.keyValue)[0];
    error.message = `${field} already exists`;
  }

  // Custom API error
  if (err instanceof ApiError) {
    error.statusCode = err.statusCode;
    error.message = err.message;
  }

  // JWT errors
  if (err.name === 'JsonWebTokenError') {
    error.statusCode = 401;
    error.message = 'Invalid token';
  }

  if (err.name === 'TokenExpiredError') {
    error.statusCode = 401;
    error.message = 'Token has expired';
  }

  // Send error response
  res.status(error.statusCode).json({
    status: error.status,
    message: error.message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};

module.exports = {
  errorHandler,
  ApiError
};
