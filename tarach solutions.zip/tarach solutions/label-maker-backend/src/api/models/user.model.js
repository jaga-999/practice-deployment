const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true
  },
  firstName: {
    type: String,
    required: true,
    trim: true
  },
  lastName: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  password: {
    type: String,
    required: true
  },
  createdDate: {
    type: Date,
    default: Date.now,
    required: true
  },
  updatedDate: {
    type: Date
  },
  lastLoginDate: {
    type: Date
  }
}, {
  timestamps: true
});

// Add this to help with population
userSchema.virtual('id').get(function() {
  return this.userId;
});

// Ensure virtuals are included in toObject and toJSON
userSchema.set('toObject', { virtuals: true });
userSchema.set('toJSON', { virtuals: true });

// Add indexes
userSchema.index({ email: 1 }, { unique: true });
userSchema.index({ userId: 1 }, { unique: true });

module.exports = mongoose.model('User', userSchema);
