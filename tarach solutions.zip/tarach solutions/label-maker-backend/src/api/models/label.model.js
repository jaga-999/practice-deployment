const mongoose = require('mongoose');
const Counter = require('./counter.model');

const labelSchema = new mongoose.Schema({
    labelId: {
        type: Number,
        unique: true,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    content: {
        type: Object,
        required: true
    },
    createdBy: {
        type: String,
        ref: 'User',
        required: true,
        localField: 'createdBy',
        foreignField: 'userId'
    },
    createdDate: {
        type: Date,
        default: Date.now,
        required: true
    },
    updatedBy: {
        type: String,
        ref: 'User',
        localField: 'updatedBy',
        foreignField: 'userId'
    },
    updatedDate: {
        type: Date
    },
    isDeleted: {
        type: Boolean,
        default: false,
        required: true
    },
    deletedBy: {
        type: String,
        ref: 'User',
        localField: 'deletedBy',
        foreignField: 'userId'
    },
    deletedDate: {
        type: Date
    }
}, {
    timestamps: true
});

// Indexes
labelSchema.index({ title: 1 });
labelSchema.index({ createdBy: 1 });
labelSchema.index({ isDeleted: 1 });
labelSchema.index({ labelId: 1 }, { unique: true });

// Add a method for soft delete
labelSchema.methods.softDelete = async function(userId) {
    this.isDeleted = true;
    this.deletedBy = userId;
    this.deletedDate = new Date();
    return await this.save();
};

// Add a method to restore
labelSchema.methods.restore = async function() {
    this.isDeleted = false;
    this.deletedBy = undefined;
    this.deletedDate = undefined;
    return await this.save();
};

// Modify default find queries to exclude deleted items
labelSchema.pre('find', function() {
    if (!this.getQuery().includeDeleted) {
        this.where({ isDeleted: false });
    }
});

labelSchema.pre('findOne', function() {
    if (!this.getQuery().includeDeleted) {
        this.where({ isDeleted: false });
    }
});

// Pre-save middleware to auto-increment labelId
labelSchema.pre('save', async function(next) {
    try {
        // Only increment if this is a new document
        if (this.isNew) {
            const counter = await Counter.findByIdAndUpdate(
                { _id: 'labelId' },
                { $inc: { seq: 1 } },
                { new: true, upsert: true }
            );
            this.labelId = counter.seq;
        }
        next();
    } catch (error) {
        next(error);
    }
});

module.exports = mongoose.model('Label', labelSchema);
