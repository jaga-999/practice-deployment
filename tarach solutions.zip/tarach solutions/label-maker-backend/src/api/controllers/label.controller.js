const LabelService = require('../services/label.service');
const { ApiError } = require('../middleware/error.middleware');

class LabelController {
  async createLabel(req, res, next) {
    try {
      const { title, content } = req.body;
      const userId = req.user?.userId;

      console.log('Controller userId:', userId);

      if (!userId) {
        throw new ApiError(401, 'Authentication required');
      }

      if (!title || !content) {
        throw new ApiError(400, 'Title and content are required');
      }

      // Check if label with same title exists for this user
      const existingLabel = await LabelService.findLabelByTitle(title, userId);
      if (existingLabel) {
        throw new ApiError(409, 'A label with this title already exists');
      }

      // Create label - just pass title and content, let service handle userId
      const newLabel = await LabelService.createLabel({ title, content }, userId);

      return res.status(201).json({
        status: 'success',
        message: 'Label created successfully',
        data: newLabel
      });

    } catch (error) {
      next(error);
    }
  }

  async updateLabel(req, res, next) {
    try {
      const { labelId, title, content } = req.body;
      const userId = req.user.userId;

      // Check if at least one field to update is provided
      if (!title && !content) {
        throw new ApiError(400, 'At least one field (title or content) must be provided for update');
      }

      const updatedLabel = await LabelService.updateLabel(
        labelId,
        { title, content },
        userId
      );

      return res.status(200).json({
        status: 'success',
        message: 'Label updated successfully',
        data: updatedLabel
      });

    } catch (error) {
      next(error);
    }
  }

  async deleteLabel(req, res, next) {
    try {
      const { labelId } = req.params;
      const userId = req.user.userId;

      console.log('Delete Label Request:', { labelId, userId });

      // Convert labelId to number since it comes as string from params
      const numericLabelId = parseInt(labelId, 10);

      if (isNaN(numericLabelId)) {
        throw new ApiError(400, 'Invalid label ID format');
      }

      const deletedLabel = await LabelService.deleteLabel(numericLabelId, userId);

      return res.status(200).json({
        status: 'success',
        message: 'Label deleted successfully',
        data: deletedLabel
      });

    } catch (error) {
      next(error);
    }
  }

  async restoreLabel(req, res, next) {
    try {
      const { labelId } = req.params;
      const userId = req.user.userId;

      const restoredLabel = await LabelService.restoreLabel(labelId, userId);

      return res.status(200).json({
        status: 'success',
        message: 'Label restored successfully',
        data: restoredLabel
      });

    } catch (error) {
      next(error);
    }
  }

  async searchLabels(req, res, next) {
    try {
      const { title, page, limit } = req.query;
      const userId = req.user.userId;

      const result = await LabelService.searchLabels(
        { title, page, limit },
        userId
      );

      return res.status(200).json({
        status: 'success',
        message: 'Labels retrieved successfully',
        data: result.labels,
        pagination: result.pagination
      });

    } catch (error) {
      next(error);
    }
  }

  async getLabels(req, res, next) {
    try {
      const { page, limit, sortBy, sortOrder } = req.query;
      const userId = req.user.userId;

      console.log('Getting labels for userId:', userId);

      const result = await LabelService.getLabels(
        { page, limit, sortBy, sortOrder },
        userId
      );

      console.log('Labels found:', result);

      return res.status(200).json({
        status: 'success',
        message: 'Labels retrieved successfully',
        data: result.labels,
        pagination: result.pagination
      });

    } catch (error) {
      next(error);
    }
  }

  async getLabelById(req, res, next) {
    try {
      const { labelId } = req.params;
      const userId = req.user.userId;

      // Convert labelId to number since it comes as string from params
      const numericLabelId = parseInt(labelId, 10);

      if (isNaN(numericLabelId)) {
        throw new ApiError(400, 'Invalid label ID format');
      }

      const label = await LabelService.getLabelDetails(numericLabelId, userId);

      return res.status(200).json({
        status: 'success',
        message: 'Label retrieved successfully',
        data: label
      });

    } catch (error) {
      next(error);
    }
  }
}

module.exports = new LabelController(); 