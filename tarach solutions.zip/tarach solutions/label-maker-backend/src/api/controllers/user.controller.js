const UserService = require('../services/user.service');
const { ApiError } = require('../middleware/error.middleware');

class UserController {
  async register(req, res, next) {
    try {
      const { firstName, lastName, email, password } = req.body;

      // Log the incoming data (remove in production)
      console.log('Registration attempt:', { firstName, lastName, email });

      const user = await UserService.createUser({
        firstName,
        lastName,
        email,
        password
      });

      return res.status(201).json({
        status: 'success',
        message: 'User registered successfully',
        data: user
      });

    } catch (error) {
      next(error);
    }
  }
}

module.exports = new UserController();
