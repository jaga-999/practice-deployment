const AuthService = require('../services/auth.service');
const { ApiError } = require('../middleware/error.middleware');

class AuthController {
  async login(req, res, next) {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        throw new ApiError(400, 'Email and password are required');
      }

      const result = await AuthService.login(email, password, req, res);
      
      return res.status(200).json({
        status: 'success',
        message: 'Login successful',
        data: {
          user: result.user
        }
      });

    } catch (error) {
      next(error);
    }
  }

  async logout(req, res, next) {
    try {
      await AuthService.logout(req, res);

      return res.status(200).json({
        status: 'success',
        message: 'Logged out successfully'
      });

    } catch (error) {
      next(error);
    }
  }

  async verifyToken(req, res, next) {
    try {
      const result = await AuthService.verifyAndRefreshTokens(req, res);
      
      return res.status(200).json({
        status: 'success',
        data: result
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new AuthController(); 