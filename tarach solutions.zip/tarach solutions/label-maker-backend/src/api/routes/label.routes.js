const express = require('express');
const router = express.Router();
const LabelController = require('../controllers/label.controller');
const { 
  createLabelValidation, 
  updateLabelValidation,
  deleteLabelValidation,
  searchLabelValidation,
  getLabelsValidation,
  getLabelByIdValidation
} = require('../middleware/validators/label.validator');
const validateRequest = require('../middleware/validate.middleware');
const { authenticateToken } = require('../middleware/auth.middleware');

// Get all labels (paginated)
router.get('/',
  authenticateToken,
  getLabelsValidation,
  validateRequest,
  LabelController.getLabels.bind(LabelController)
);

// Create new label
router.post('/create',
  authenticateToken,
  createLabelValidation,
  validateRequest,
  LabelController.createLabel.bind(LabelController)
);

// Update existing label
router.put('/update',
  authenticateToken,
  updateLabelValidation,
  validateRequest,
  LabelController.updateLabel.bind(LabelController)
);

// Delete label (soft delete)
router.delete('/:labelId',
  authenticateToken,
  deleteLabelValidation,
  validateRequest,
  LabelController.deleteLabel.bind(LabelController)
);

// Restore deleted label
router.post('/:labelId/restore',
  authenticateToken,
  deleteLabelValidation,
  validateRequest,
  LabelController.restoreLabel.bind(LabelController)
);

// Search labels
router.get('/search',
  authenticateToken,
  searchLabelValidation,
  validateRequest,
  LabelController.searchLabels.bind(LabelController)
);

// Get label by ID
router.get('/:labelId',
  authenticateToken,
  getLabelByIdValidation,
  validateRequest,
  LabelController.getLabelById.bind(LabelController)
);

module.exports = router; 