const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/auth.controller');
const { 
  loginValidation,
  logoutValidation,
  verifyTokenValidation 
} = require('../middleware/validators/auth.validator');
const validateRequest = require('../middleware/validate.middleware');
const { authenticateToken } = require('../middleware/auth.middleware');

// Login route
router.post('/login', 
  loginValidation,
  validateRequest,
  AuthController.login.bind(AuthController)
);

// Logout route
router.post('/logout',
  authenticateToken,
  logoutValidation,
  validateRequest,
  AuthController.logout.bind(AuthController)
);

// Verify token route
router.post('/verify-token',
  verifyTokenValidation,
  validateRequest,
  AuthController.verifyToken.bind(AuthController)
);

module.exports = router; 