const express = require('express');
const router = express.Router();
const UserController = require('../controllers/user.controller');
const { registerValidation } = require('../middleware/validators/user.validator');
const validateRequest = require('../middleware/validate.middleware');

router.post('/register', registerValidation, validateRequest, UserController.register.bind(UserController));

module.exports = router;
