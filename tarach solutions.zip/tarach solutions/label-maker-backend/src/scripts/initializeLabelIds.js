const mongoose = require('mongoose');
const Label = require('../api/models/label.model');
const Counter = require('../api/models/counter.model');

async function initializeLabelIds() {
  try {
    // Get all labels without labelId
    const labels = await Label.find({ labelId: { $exists: false } })
      .sort({ createdDate: 1 });

    // Initialize counter
    let counter = await Counter.findById('labelId');
    if (!counter) {
      counter = new Counter({ _id: 'labelId', seq: 0 });
    }

    // Update each label
    for (const label of labels) {
      counter.seq += 1;
      label.labelId = counter.seq;
      await label.save();
    }

    await counter.save();
    
    console.log('Label IDs initialized successfully');
  } catch (error) {
    console.error('Error initializing label IDs:', error);
  } finally {
    mongoose.disconnect();
  }
}

// Run the migration
mongoose.connect(process.env.MONGODB_URI)
  .then(() => initializeLabelIds())
  .catch(console.error); 