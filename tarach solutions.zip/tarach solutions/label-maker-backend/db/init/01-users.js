db.createCollection("users", {
   validator: {
      $jsonSchema: {
         bsonType: "object",
         required: ["username", "firstName", "lastName", "password", "email", "createdDate"],
         properties: {
            username: {
               bsonType: "string",
               description: "Username must be a string and is required"
            },
            firstName: {
               bsonType: "string",
               description: "First name must be a string and is required"
            },
            lastName: {
               bsonType: "string",
               description: "Last name must be a string and is required"
            },
            password: {
               bsonType: "string",
               description: "Password must be a string and is required"
            },
            email: {
               bsonType: "string",
               pattern: "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
               description: "Email must be a valid email address and is required"
            },
            createdDate: {
               bsonType: "date",
               description: "Created date must be a date and is required"
            },
            updatedDate: {
               bsonType: "date",
               description: "Updated date must be a date"
            }
         }
      }
   }
});

// Create indexes
db.users.createIndex({ "username": 1 }, { unique: true });
db.users.createIndex({ "email": 1 }, { unique: true });
