// First create the counter collection
db.createCollection("counters", {
   validator: {
      $jsonSchema: {
         bsonType: "object",
         required: ["_id", "seq"],
         properties: {
            _id: {
               bsonType: "string",
               description: "Counter name must be a string and is required"
            },
            seq: {
               bsonType: "number",
               description: "Sequence must be a number and is required"
            }
         }
      }
   }
});

// Initialize the label counter
db.counters.insertOne({
   _id: "labelId",
   seq: 0
});

// Create the labels collection with labelId
db.createCollection("labels", {
   validator: {
      $jsonSchema: {
         bsonType: "object",
         required: ["labelId", "title", "content", "createdBy", "createdDate", "isDeleted"],
         properties: {
            labelId: {
               bsonType: "number",
               description: "Label ID must be a number and is required"
            },
            title: {
               bsonType: "string",
               description: "Title must be a string and is required"
            },
            content: {
               bsonType: "object",
               description: "Content must be a JSON object and is required"
            },
            createdBy: {
               bsonType: "string",
               description: "Created by user ID must be a string and is required"
            },
            createdDate: {
               bsonType: "date",
               description: "Created date must be a date and is required"
            },
            updatedBy: {
               bsonType: "string",
               description: "Updated by user ID must be a string"
            },
            updatedDate: {
               bsonType: "date",
               description: "Updated date must be a date"
            },
            isDeleted: {
               bsonType: "bool",
               description: "isDeleted must be a boolean and is required",
               default: false
            },
            deletedBy: {
               bsonType: "string",
               description: "Deleted by user ID must be a string"
            },
            deletedDate: {
               bsonType: "date",
               description: "Deleted date must be a date"
            }
         }
      }
   }
});

// Create indexes
db.labels.createIndex({ "labelId": 1 }, { unique: true });
db.labels.createIndex({ "title": 1 });
db.labels.createIndex({ "createdBy": 1 });
db.labels.createIndex({ "isDeleted": 1 });
