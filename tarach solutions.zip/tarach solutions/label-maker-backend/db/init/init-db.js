const { MongoClient } = require('mongodb');
require('dotenv').config();

async function initializeDatabase() {
    try {
        const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/nf-label-maker';
        
        console.log('Connecting to MongoDB...');
        
        const client = new MongoClient(uri, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });

        await client.connect();
        console.log('Connected to MongoDB successfully');

        const db = client.db('nf-label-maker');

        // Initialize collections
        await initializeCollections(db);

        return client;
    } catch (error) {
        console.error('Database initialization error:', error);
        throw error;
    }
}

async function initializeCollections(db) {
    try {
        // Drop existing collections if they exist
        const collections = await db.listCollections().toArray();
        for (const collection of collections) {
            await db.collection(collection.name).drop();
        }
        console.log('Existing collections dropped successfully');

        // Create Users collection with updated validation
        await db.createCollection("users", {
            validator: {
                $jsonSchema: {
                    bsonType: "object",
                    required: ["userId", "firstName", "lastName", "password", "email", "createdDate"],
                    properties: {
                        userId: {
                            bsonType: "string",
                            description: "UserId must be a string and is required"
                        },
                        firstName: {
                            bsonType: "string",
                            description: "First name must be a string and is required"
                        },
                        lastName: {
                            bsonType: "string",
                            description: "Last name must be a string and is required"
                        },
                        password: {
                            bsonType: "string",
                            description: "Password must be a string and is required"
                        },
                        email: {
                            bsonType: "string",
                            pattern: "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
                            description: "Email must be a valid email address and is required"
                        },
                        createdDate: {
                            bsonType: "date",
                            description: "Created date must be a date and is required"
                        },
                        updatedDate: {
                            bsonType: "date",
                            description: "Updated date must be a date"
                        }
                    }
                }
            }
        });

        // Create unique indexes
        await db.collection("users").createIndex({ "userId": 1 }, { unique: true });
        await db.collection("users").createIndex({ "email": 1 }, { unique: true });

        // Create Labels collection with validation
        await db.createCollection("labels", {
            validator: {
                $jsonSchema: {
                    bsonType: "object",
                    required: ["title", "content", "createdBy", "createdDate"],
                    properties: {
                        title: {
                            bsonType: "string",
                            description: "Title must be a string and is required"
                        },
                        content: {
                            bsonType: "object",
                            description: "Content must be an object and is required"
                        },
                        createdBy: {
                            bsonType: "string",
                            description: "Created by must be a userId and is required"
                        },
                        updatedBy: {
                            bsonType: "string",
                            description: "Updated by must be a userId"
                        },
                        deletedBy: {
                            bsonType: "string",
                            description: "Deleted by must be a userId"
                        },
                        createdDate: {
                            bsonType: "date",
                            description: "Created date must be a date and is required"
                        },
                        updatedDate: {
                            bsonType: "date",
                            description: "Updated date must be a date"
                        },
                        deletedDate: {
                            bsonType: "date",
                            description: "Deleted date must be a date"
                        },
                        isDeleted: {
                            bsonType: "bool",
                            description: "Is deleted must be a boolean"
                        }
                    }
                }
            }
        });

        // Create compound index for title and createdBy
        await db.collection("labels").createIndex(
            { "title": 1, "createdBy": 1 },
            { unique: true, partialFilterExpression: { isDeleted: false } }
        );

        // Create Tokens collection with validation
        await db.createCollection("tokens", {
            validator: {
                $jsonSchema: {
                    bsonType: "object",
                    required: ["userId", "accessToken", "refreshToken", "accessTokenExpiresAt", "refreshTokenExpiresAt"],
                    properties: {
                        userId: {
                            bsonType: "string",
                            description: "User ID must be a string and is required"
                        },
                        accessToken: {
                            bsonType: "string",
                            description: "Access token must be a string and is required"
                        },
                        refreshToken: {
                            bsonType: "string",
                            description: "Refresh token must be a string and is required"
                        },
                        accessTokenExpiresAt: {
                            bsonType: "date",
                            description: "Access token expiry must be a date and is required"
                        },
                        refreshTokenExpiresAt: {
                            bsonType: "date",
                            description: "Refresh token expiry must be a date and is required"
                        },
                        deviceInfo: {
                            bsonType: "string",
                            description: "Device info must be a string"
                        },
                        ipAddress: {
                            bsonType: "string",
                            description: "IP address must be a string"
                        },
                        isValid: {
                            bsonType: "bool",
                            description: "Is valid must be a boolean"
                        },
                        createdAt: {
                            bsonType: "date",
                            description: "Created at must be a date"
                        }
                    }
                }
            }
        });
        
        // Create index on userId and isValid
await db.collection("tokens").createIndex({ userId: 1, isValid: 1 });


        console.log('Collections initialized successfully');
    } catch (error) {
        console.error('Error initializing collections:', error);
        throw error;
    }
}

// Initialize database when this file is run directly
if (require.main === module) {
    initializeDatabase()
        .then(() => {
            console.log('Database initialization completed');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Database initialization failed:', error);
            process.exit(1);
        });
}

module.exports = initializeDatabase;