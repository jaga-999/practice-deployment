import axiosInstance from './axiosConfig';
import { CREATE_LABEL_API_PATH, GET_ALL_LABELS_API_PATH, GET_LABEL_DETAILS_API_PATH, UPDATE_LABEL_API_PATH, DELETE_LABEL_API_PATH } from '../utilities/apiPaths';
import { CreateLabelRequest, Label, LabelDetailsResponse, GetLabelsParams, SingleLabelResponse, UpdateLabelRequest, UpdateLabelResponse, DeleteLabelResponse } from '../types/label.types';

export const createLabel = async (labelData: CreateLabelRequest): Promise<Label> => {
  const response = await axiosInstance.post<any, Label>(CREATE_LABEL_API_PATH, labelData);
  return response;
};

export const getLabelDetails = async (labelId: string | number): Promise<Label> => {
  const response = await axiosInstance.get<any, SingleLabelResponse>(
    `${GET_LABEL_DETAILS_API_PATH}/${labelId}`
  );
  return response.data;
};

export const getAllLabels = async (params: GetLabelsParams = {}): Promise<LabelDetailsResponse> => {
  const { page = 1, limit = 10, sortBy = 'createdDate', sortOrder = 'desc' } = params;
  const queryParams = new URLSearchParams({
    page: page.toString(),
    limit: limit.toString(),
    sortBy,
    sortOrder
  });
  
  const response = await axiosInstance.get<any, LabelDetailsResponse>(
    `${GET_ALL_LABELS_API_PATH}?${queryParams.toString()}`
  );
  return response;
};

export const updateLabel = async (updateData: UpdateLabelRequest): Promise<Label> => {
  const response = await axiosInstance.put<any, UpdateLabelResponse>(
    UPDATE_LABEL_API_PATH,
    updateData
  );
  return response.data;
};

export const deleteLabel = async (labelId: string | number): Promise<Label> => {
  const response = await axiosInstance.delete<any, DeleteLabelResponse>(
    `${DELETE_LABEL_API_PATH}/${labelId}`
  );
  return response.data;
};

