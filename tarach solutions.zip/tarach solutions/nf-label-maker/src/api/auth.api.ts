import axios from './axiosConfig';
import { REGISTER_API_PATH, LOGIN_API_PATH, LOGOUT_API_PATH } from '../utilities/apiPaths';
import { RegisterRequest, RegisterResponse, LoginRequest, LoginResponse, VerifyTokenResponse } from '../types/auth.types';

export const register = (userData: RegisterRequest): Promise<RegisterResponse> => {
  return axios.post(REGISTER_API_PATH, userData);
};

export const login = (credentials: LoginRequest): Promise<LoginResponse> => {
  return axios.post(LOGIN_API_PATH, credentials);
};

export const verifyToken = (): Promise<VerifyTokenResponse> => {
  return axios.post('/api/auth/verify-token');
};

export const logout = async (): Promise<void> => {
  return axios.post(LOGOUT_API_PATH);
}; 