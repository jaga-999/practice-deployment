import React, { useState } from 'react';
import {
  Box,
  Card,
  TextField,
  Button,
  Typography,
  Link,
  InputAdornment,
} from '@mui/material';
import { AccountCircle, Lock } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import Landing from './Landing';
import { login } from '../api/auth.api';
import { useAuth } from '../context/AuthContext';

const DEFAULT_CREDENTIALS = {
  username: 'John Doe',
  password: 'demo123',
};

const Login: React.FC = () => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { verifyAuthentication } = useAuth();

  const handleLogin = async () => {
    try {
      const response = await login({
        email: credentials.username,
        password: credentials.password
      });

      if (response.status === 'success' && response.data) {
        sessionStorage.setItem('user', JSON.stringify(response.data.user));
        await verifyAuthentication();
        navigate('/home');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: { xs: 'column', md: 'row' },
        height: '100vh',
        background: 'linear-gradient(to right, #00416A, #E4E5E6)',
      }}
    >
      <Landing />

      {/* Right Section */}
      <Box
        sx={{
          flex: 1,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#fff',
          background: 'linear-gradient(to left, #00416A, #E4E5E6)',
          padding: 4,
        }}
      >
        <Card sx={{ p: 4, width: '100%', maxWidth: 400, borderRadius: '16px', }}>
          <Typography variant="h5" sx={{ textAlign: 'center', mb: 3, fontWeight: 'bold' }}>
            Welcome to <br></br>Nutrition Facts Label Maker
          </Typography>
          {error && (
            <Typography color="error" align="center" sx={{ mb: 2 }}>
              {error}
            </Typography>
          )}
          {/* Email Field (previously Username) */}
          <TextField
            fullWidth
            label="Email"
            variant="outlined"
            margin="normal"
            value={credentials.username}
            onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <AccountCircle style={{ color: '#72BCD4' }} />
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                '&.Mui-focused fieldset': {
                  borderColor: '#72BCD4',
                },
              },
              '& .MuiInputLabel-root.Mui-focused': {
                color: '#30839F',
              },
            }}
          />
          {/* Password Field */}
          <TextField
            fullWidth
            label="Password"
            type="password"
            variant="outlined"
            margin="normal"
            value={credentials.password}
            onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Lock style={{ color: '#72BCD4' }} />
                </InputAdornment>
              ),
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                '&.Mui-focused fieldset': {
                  borderColor: '#72BCD4',
                },
              },
              '& .MuiInputLabel-root.Mui-focused': {
                color: '#30839F',
              },
            }}
          />
          <Button
            fullWidth
            variant="contained"
            onClick={handleLogin}
            sx={{
              mt: 3,
              background: 'linear-gradient(45deg, #E4E5E6,#00416A)',
              color: 'black',
              '&:hover': {
                background: 'linear-gradient(45deg, #72BCD4, #72BCD4)',
              },
            }}
          >
            Sign In
          </Button>
          <Typography variant="body2" align="center" sx={{ mt: 2 }}>
            Don’t have an account?{' '}
            <Link
              component="button"
              variant="body2"
              onClick={() => navigate('/register')}
              sx={{
                color: '#72BCD4',
                fontWeight: 'bold',
                textDecoration: 'none',
              }}
            >
              Sign Up
            </Link>
          </Typography>
        </Card>
      </Box>
    </Box>
  );
};

export default Login;
