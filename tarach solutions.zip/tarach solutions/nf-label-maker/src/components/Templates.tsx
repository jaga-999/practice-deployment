import React, { useState } from 'react';
import { Card, CardContent, CardMedia, Typography, Grid, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import Standard_Vertical from '../assets/Standard_Vertical.webp';
import Vertical_Display from '../assets/Vertical_Display_with_Micronutrients_Listed_Side_by_Side.webp';
import Navbar from './Navbar';
import Sidebar from './Sidebar';

const Templates = () => {
  const navigate = useNavigate();
  const [isDrawerExpanded, setIsDrawerExpanded] = useState(false);

  const handleCardClick = () => {
    navigate('/create-label', {
      state: {
        productTitle: 'New Product',
        mandatorySections: {
          servingsPerContainer: '8',
          servingSize: '2/3 cup (55g)',
          calories: '230'
        }
      }
    });
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <Navbar />
      <div style={{ display: 'flex', flex: 1 }}>
        <Sidebar 
          isDrawerExpanded={isDrawerExpanded}
          setIsDrawerExpanded={setIsDrawerExpanded}
        />

        {/* Main Content */}
        <div style={{ 
          padding: '32px', 
          flexGrow: 1, 
          marginTop: '70px',
          marginLeft: '10px',
          width: `calc(100% - ${isDrawerExpanded ? 240 : 64}px)`,
          transition: 'width 0.2s ease-in-out'
        }}>
          <Box 
            sx={{ 
              display: 'flex',
              flexWrap: 'wrap',
              gap: '16px',
              justifyContent: 'center',
              alignItems: 'center',
              width: '95%',
              maxWidth: '1360px',
              margin: '0 auto',
              padding: '16px',
              backgroundColor: '#f5f5f5',
              borderRadius: '8px',
              minHeight: '430px'
            }}
          >
            <Typography 
              variant="h5" 
              gutterBottom 
              align="center" 
              sx={{ 
                width: '100%',
                color: '#59819B',
                fontWeight: 600,
                fontSize: '1rem',
                textTransform: 'uppercase',
                letterSpacing: '0.1em',
                padding: '20px 0',
                borderBottom: '3px solid #59819B',
                marginBottom: '40px',
                position: 'relative',
                '&::after': {
                  content: '""',
                  position: 'absolute',
                  bottom: '-10px',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  width: '50px',
                  height: '4px',
                  backgroundColor: '#59819B',
                  borderRadius: '2px'
                },
                textShadow: '2px 2px 4px rgba(0, 0, 0, 0.1)'
              }}
            >
              Please Select a Template
            </Typography>
            <Grid 
              container 
              spacing={4} 
              justifyContent="center"
              sx={{ 
                marginTop: '-150px'
              }}
            >
              <Grid item xs={12} md={5}>
                <Card 
                  sx={{ 
                    cursor: 'pointer',
                    backgroundColor: '#59819B',
                    '&:hover': { 
                      backgroundColor: '#4A7083'
                    },
                    transform: 'scale(0.8)',
                    transformOrigin: 'center',
                    margin: 'auto',
                    pt: '5px'
                  }}
                  onClick={handleCardClick}
                >
                  <Typography variant="h6" sx={{ color: '#ffffff', p: 1 }} align="center">
                    Standard Vertical Format
                  </Typography>
                  <CardMedia
                    component="img"
                    image={Standard_Vertical}
                    alt="Standard Vertical Nutrition Label"
                    sx={{ 
                      width: '100%',
                      height: 'auto',
                      objectFit: 'contain'
                    }}
                  />
                </Card>
              </Grid>
              <Grid item xs={12} md={5}>
                <Card 
                  sx={{ 
                    cursor: 'pointer',
                    backgroundColor: '#59819B',
                    '&:hover': { 
                      backgroundColor: '#4A7083'
                    },
                    transform: 'scale(0.8)',
                    transformOrigin: 'center',
                    margin: 'auto',
                    pt: '5px'
                  }}
                  // onClick={handleCardClick}
                >
                  <Typography variant="h6" sx={{ color: '#ffffff', p: 1 }} align="center">
                    Vertical Display with Side-by-Side Micronutrients
                  </Typography>
                  <CardMedia
                    component="img"
                    image={Vertical_Display}
                    alt="Vertical Display with Side-by-Side Micronutrients"
                    sx={{ 
                      width: '100%',
                      height: 'auto',
                      objectFit: 'contain'
                    }}
                  />
                </Card>
              </Grid>
            </Grid>
          </Box>
        </div>
      </div>
    </div>
  );
};

export default Templates;
