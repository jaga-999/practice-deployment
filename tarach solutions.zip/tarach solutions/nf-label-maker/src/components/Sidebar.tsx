import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Drawer, List, ListItem, ListItemIcon, ListItemText, Box } from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import CreateIcon from '@mui/icons-material/Create';
import ArticleIcon from '@mui/icons-material/Article';
import ContactSupportIcon from '@mui/icons-material/ContactSupport';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';

interface SidebarProps {
  isDrawerExpanded: boolean;
  setIsDrawerExpanded: (expanded: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isDrawerExpanded, setIsDrawerExpanded }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleAddClick = () => {
    navigate('/templates');
  };

  return (
    <Drawer
      variant="permanent"
      onMouseEnter={() => setIsDrawerExpanded(true)}
      onMouseLeave={() => setIsDrawerExpanded(false)}
      sx={{
        width: isDrawerExpanded ? 240 : 64,
        transition: 'width 0.2s ease-in-out',
        '& .MuiDrawer-paper': {
          width: isDrawerExpanded ? 240 : 64,
          boxSizing: 'border-box',
          background: 'linear-gradient(to right, #00416A, #E4E5E6)',
          marginTop: '64px',
          height: 'calc(100% - 64px)',
          position: 'fixed',
          overflowX: 'hidden',
          overflowY: 'hidden',
          transition: 'width 0.2s ease-in-out',
          whiteSpace: 'nowrap',
        },
      }}
    >
      <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <List>
          <ListItem 
            sx={{ 
              cursor: 'pointer',
              backgroundColor: location.pathname === '/home' ? 'rgba(0, 0, 0, 0.2)' : 'transparent',
              '&:hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
              },
            }} 
            onClick={() => navigate('/home')}
          >
            <ListItemIcon>
              <DashboardIcon sx={{ color: '#ffffff' }} />
            </ListItemIcon>
            <ListItemText 
              primary="Dashboard" 
              sx={{ 
                opacity: isDrawerExpanded ? 1 : 0, 
                transition: 'opacity 0.2s',
                color: '#ffffff'
              }} 
            />
          </ListItem>
          <ListItem 
            sx={{ 
              cursor: 'pointer',
              backgroundColor: ['/templates', '/create-label'].includes(location.pathname) ? 'rgba(0, 0, 0, 0.2)' : 'transparent',
              '&:hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
              },
            }} 
            onClick={handleAddClick}
          >
            <ListItemIcon>
              <CreateIcon sx={{ color: '#ffffff' }} />
            </ListItemIcon>
            <ListItemText 
              primary="Create Label" 
              sx={{ 
                opacity: isDrawerExpanded ? 1 : 0, 
                transition: 'opacity 0.2s',
                color: '#ffffff'
              }} 
            />
          </ListItem>
          <ListItem sx={{ cursor: 'pointer' }} onClick={() => navigate('/audit-logs')}>
            <ListItemIcon>
              <ArticleIcon sx={{ color: '#ffffff' }} />
            </ListItemIcon>
            <ListItemText 
              primary="Audit Logs" 
              sx={{ 
                opacity: isDrawerExpanded ? 1 : 0, 
                transition: 'opacity 0.2s',
                color: '#ffffff'
              }} 
            />
          </ListItem>
        </List>

        <Box sx={{ flexGrow: 1 }} />
        
        <List>
          <ListItem 
            sx={{ 
              cursor: 'pointer',
              backgroundColor: location.pathname === '/profile' ? 'rgba(0, 0, 0, 0.2)' : 'transparent',
              '&:hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
              },
            }} 
            onClick={() => navigate('/profile')}
          >
            <ListItemIcon>
              <AccountCircleIcon sx={{ color: '#ffffff' }} />
            </ListItemIcon>
            <ListItemText 
              primary="Profile" 
              sx={{ 
                opacity: isDrawerExpanded ? 1 : 0, 
                transition: 'opacity 0.2s',
                color: '#ffffff'
              }} 
            />
          </ListItem>
          <ListItem sx={{ cursor: 'pointer' }} onClick={() => navigate('/contact')}>
            <ListItemIcon>
              <ContactSupportIcon sx={{ color: '#ffffff' }} />
            </ListItemIcon>
            <ListItemText 
              primary="Contact Us" 
              sx={{ 
                opacity: isDrawerExpanded ? 1 : 0, 
                transition: 'opacity 0.2s',
                color: '#ffffff'
              }} 
            />
          </ListItem>
        </List>
      </Box>
    </Drawer>
  );
};

export default Sidebar; 