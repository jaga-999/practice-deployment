import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, Modal, Button, Box, Dialog, DialogTitle, DialogActions, IconButton, Menu, MenuItem, Avatar, Drawer, List, ListItem, ListItemIcon, ListItemText, Typography, CircularProgress } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import nutritionFactsLabel from '../assets/nutritionFactsLabel.png';
import LoginIcon from '@mui/icons-material/Login';
import DeleteIcon from '@mui/icons-material/Delete';
import CloseIcon from '@mui/icons-material/Close';
import DashboardIcon from '@mui/icons-material/Dashboard';
import CreateIcon from '@mui/icons-material/Create';
import ArticleIcon from '@mui/icons-material/Article';
import ContactSupportIcon from '@mui/icons-material/ContactSupport';
import undraw from '../assets/undraw.svg';
import Label from '../assets/Label.jpg';
import Navbar from './Navbar';
import { getAllLabels, getLabelDetails, deleteLabel } from '../api/labels.api';
import { GetLabelsParams } from '../types/label.types';
import Sidebar from './Sidebar';

interface NutritionData {
  labelId: number;
  title: string;
  createdDate: string;
  createdBy: {
    _id: string;
    userId: string;
    firstName: string;
    lastName: string;
    email: string;
  };
  // Add other fields as needed
}

const Home: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [savedLabels, setSavedLabels] = useState<NutritionData[]>([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [labelToDelete, setLabelToDelete] = useState<string | null>(null);
  const [isDrawerExpanded, setIsDrawerExpanded] = useState(false);
  const [showCreateLabelModal, setShowCreateLabelModal] = useState(false);
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    const fetchLabels = async () => {
      try {
        setIsLoading(true);
        const response = await getAllLabels({
          page: currentPage,
          limit: 10,
          sortBy: 'createdDate',
          sortOrder: 'desc'
        });
        
        // Map the API response to match our NutritionData interface
        const formattedLabels: NutritionData[] = response.data.map(label => ({
          labelId: label.labelId,
          title: label.title,
          createdDate: label.createdDate,
          createdBy: label.createdBy
        }));
        
        setSavedLabels(formattedLabels);
        setTotalPages(response.pagination.totalPages);
      } catch (err) {
        setError('Failed to fetch labels');
        console.error('Error fetching labels:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchLabels();
  }, [currentPage]);

  const handleAddClick = () => {
    navigate('/templates');
  };

  const handleSavedLabelClick = async (labelId: number) => {
    try {
      const labelDetails = await getLabelDetails(labelId);
      
      // Extract the content data from labelDetails
      const content = labelDetails.content as {
        mandatorySections?: {
          servingsPerContainer: string;
          servingSize: string;
          calories: string;
        };
        mandatoryIngredients?: Array<{
          name: string;
          amount: number;
          unit: string;
          dailyValue: number;
        }>;
        additionalIngredients?: Array<{
          name: string;
          dosage: string;
          unit: string;
          dailyValue: string;
        }>;
      };

      // Navigate with properly structured state, now including labelId
      navigate('/view-label', {
        state: {
          labelId: labelId,
          existingId: labelDetails._id,
          productTitle: labelDetails.title,
          mandatorySections: content.mandatorySections || {
            servingsPerContainer: '8',
            servingSize: '2/3 cup (55g)',
            calories: '230'
          },
          mandatoryIngredients: content.mandatoryIngredients || [],
          additionalIngredients: content.additionalIngredients || []
        }
      });
    } catch (error) {
      console.error('Error fetching label details:', error);
      setError('Failed to fetch label details');
    }
  };

  const handleDeleteClick = (event: React.MouseEvent, labelId: string) => {
    event.stopPropagation();
    setLabelToDelete(labelId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (labelToDelete) {
      try {
        await deleteLabel(labelToDelete);
        const updatedLabels = savedLabels.filter(label => label.labelId.toString() !== labelToDelete);
        setSavedLabels(updatedLabels);
      } catch (err) {
        console.error('Error deleting label:', err);
        setError('Failed to delete label');
      }
    }
    setDeleteDialogOpen(false);
    setLabelToDelete(null);
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
    setLabelToDelete(null);
  };

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
  };

  return (
    <div className="home" style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <Navbar />
      <div style={{ display: 'flex', flex: 1 }}>
        <Sidebar 
          isDrawerExpanded={isDrawerExpanded}
          setIsDrawerExpanded={setIsDrawerExpanded}
        />

        {/* Main Content */}
        <div className="content" style={{ 
          padding: '32px', 
          flexGrow: 1, 
          marginTop: '70px',
          marginLeft: '10px',
          width: `calc(100% - ${isDrawerExpanded ? 240 : 64}px)`,
          transition: 'width 0.2s ease-in-out'
        }}>
          <Box 
            sx={{ 
              display: 'flex',
              flexWrap: 'wrap',
              gap: '16px',
              justifyContent: 'center',
              alignItems: 'center',
              width: '95%',
              maxWidth: '1360px',
              margin: '0 auto',
              padding: '16px',
              backgroundColor: '#f5f5f5',
              borderRadius: '8px',
              minHeight: '430px'
            }}
          >
            {isLoading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                <CircularProgress />
              </Box>
            ) : error ? (
              <Typography color="error" sx={{ textAlign: 'center', p: 3 }}>
                {error}
              </Typography>
            ) : (
              <>
                {savedLabels.length === 0 ? (
                  <Box sx={{ textAlign: 'center' }}>
                    <img 
                      src={undraw}
                      alt="Create new label"
                      style={{ 
                        width: '200px',
                        marginBottom: '20px',
                        cursor: 'pointer'
                      }}
                      onClick={handleAddClick}
                    />
                    <Typography variant="h5">
                     Click on the image above to create a new label
                    </Typography>
                  </Box>
                ) : (
                  /* Saved Labels */
                  savedLabels.map((label) => (
                    <Card
                      key={label.labelId}
                      sx={{
                        width: 250,
                        height: 350,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        cursor: 'pointer',
                        backgroundColor: '#59819B',
                        position: 'relative',
                        '&:hover': { 
                          backgroundColor: '#4A7083'
                        }
                      }}
                      onClick={() => handleSavedLabelClick(label.labelId)}
                    >
                      <img 
                        src={nutritionFactsLabel}
                        alt="Nutrition Label"
                        style={{
                          width: '100%',
                          height: '70%',
                          objectFit: 'cover',
                          objectPosition: 'top',
                          maxWidth: '100%'
                        }}
                      />
                      <Typography
                        sx={{
                          color: '#ffffff',
                          fontSize: '1.2rem',
                          fontWeight: 500,
                          my: 1,
                          textAlign: 'center',
                          px: 2,
                          textShadow: '1px 1px 2px rgba(0, 0, 0, 0.2)'
                        }}
                      >
                        {label.title}
                      </Typography>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          color: '#ffffff',
                          textAlign: 'center',
                          mb: 2
                        }}
                      >
                        Created: {new Date(label.createdDate).toLocaleDateString()}
                      </Typography>
                      <Box sx={{ 
                        position: 'absolute',
                        bottom: 8,
                        right: 8
                      }}>
                        <Button
                          onClick={(e) => handleDeleteClick(e, label.labelId.toString())}
                          sx={{
                            minWidth: 'auto',
                            padding: '6px',
                          }}
                        >
                          <DeleteIcon sx={{ color: '#ff6666' }} />
                        </Button>
                      </Box>
                    </Card>
                  ))
                )}
                {/* {savedLabels.length > 0 && (
                  <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
                    <Button 
                      disabled={currentPage === 1}
                      onClick={() => handlePageChange(currentPage - 1)}
                    >
                      Previous
                    </Button>
                    <Typography sx={{ mx: 2 }}>
                      Page {currentPage} of {totalPages}
                    </Typography>
                    <Button 
                      disabled={currentPage === totalPages}
                      onClick={() => handlePageChange(currentPage + 1)}
                    >
                      Next
                    </Button>
                  </Box>
                )} */}
              </>
            )}
          </Box>

          <Dialog
            open={deleteDialogOpen}
            onClose={handleDeleteCancel}
          >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', pr: 1 }}>
              <DialogTitle>Are you sure you want to delete this label?</DialogTitle>
              <IconButton onClick={handleDeleteCancel} sx={{ color: 'red',marginTop:'-30px' }}>
                <CloseIcon />
              </IconButton>
            </Box>
            <DialogActions sx={{ justifyContent: 'center' }}>
              <Button 
                onClick={handleDeleteCancel} 
                sx={{ 
                  backgroundColor: '#59819B', 
                  color: '#ffffff',
                  '&:hover': {
                    backgroundColor: '#4A7083'
                  }
                }}
              >
                No
              </Button>
              <Button 
                onClick={handleDeleteConfirm} 
                sx={{ 
                  backgroundColor: '#59819B', 
                  color: '#ffffff',
                  '&:hover': {
                    backgroundColor: '#4A7083'
                  }
                }} 
                autoFocus
              >
                Yes
              </Button>
            </DialogActions>
          </Dialog>

          {/* Create Label Modal */}
          {/* <Dialog
            open={showCreateLabelModal}
            onClose={handleModalClose}
            maxWidth="md"
          >
            <Box sx={{ p: 2, textAlign: 'center' }}>
              <img
                src={Label}
                alt="Create Label"
                style={{
                  width: '100%',
                  maxWidth: '400px',
                  height: 'auto'
                }}
              />
              <DialogActions sx={{ justifyContent: 'center', mt: 2 }}>
                <Button
                  onClick={handleModalClose}
                  sx={{
                    backgroundColor: '#B0DAE9',
                    color: 'black',
                    '&:hover': {
                      backgroundColor: '#ADD8E6'
                    }
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleCreateLabel}
                  sx={{
                    backgroundColor: '#B0DAE9',
                    color: 'black',
                    '&:hover': {
                      backgroundColor: '#ADD8E6'
                    }
                  }}
                  autoFocus
                >
                  Create Label
                </Button>
              </DialogActions>
            </Box>
          </Dialog> */}
        </div>
      </div>
    </div>
  );
};

export default Home;
