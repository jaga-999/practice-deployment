import React, { useState, useEffect } from 'react';
import { Card, CardContent, Typography, TextField, Button, Box, Grid } from '@mui/material';
import Navbar from './Navbar';
import Sidebar from './Sidebar';

interface UserProfile {
  firstName: string;
  lastName: string;
  email: string;
  company: string;
  phone: string;
}

const Profile = () => {
  const [isDrawerExpanded, setIsDrawerExpanded] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({
    firstName: '',
    lastName: '',
    email: '',
    company: '',
    phone: ''
  });

  useEffect(() => {
    // Load user data from sessionStorage instead of localStorage
    const userStr = sessionStorage.getItem('user');
    if (userStr) {
      const userData = JSON.parse(userStr);
      setProfile(prevProfile => ({
        ...prevProfile,
        ...userData
      }));
    }
  }, []);

  const handleChange = (field: keyof UserProfile) => (event: React.ChangeEvent<HTMLInputElement>) => {
    setProfile(prev => ({
      ...prev,
      [field]: event.target.value
    }));
  };

  const handleSubmit = () => {
    // Save to sessionStorage instead of localStorage
    const userStr = sessionStorage.getItem('user');
    if (userStr) {
      const userData = JSON.parse(userStr);
      sessionStorage.setItem('user', JSON.stringify({
        ...userData,
        ...profile
      }));
    }
    setIsEditing(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <Navbar />
      <div style={{ display: 'flex', flex: 1 }}>
        <Sidebar 
          isDrawerExpanded={isDrawerExpanded}
          setIsDrawerExpanded={setIsDrawerExpanded}
        />

        <Box sx={{ 
          flexGrow: 1,
          marginLeft: isDrawerExpanded ? '100px' : '64px',
          width: isDrawerExpanded ? 'calc(100% - 240px)' : 'calc(100% - 64px)',
          transition: 'margin-left 0.2s ease-in-out, width 0.2s ease-in-out',
          padding: 3,
          marginTop: '64px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#f5f5f5'
        }}>
          <Card sx={{ 
            maxWidth: '500px', 
            margin: '0 auto',
            bgcolor: '#f5f5f5'
          }}>
            <CardContent>
              <Typography variant="h4" gutterBottom>
                Profile
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" component="label">
                    First Name
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    value={profile.firstName}
                    onChange={handleChange('firstName')}
                    disabled={!isEditing}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '&.Mui-focused fieldset': {
                          borderColor: '#ADD8E6',
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" component="label">
                    Last Name
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    value={profile.lastName}
                    onChange={handleChange('lastName')}
                    disabled={!isEditing}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '&.Mui-focused fieldset': {
                          borderColor: '#ADD8E6',
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" component="label">
                    Email
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    value={profile.email}
                    onChange={handleChange('email')}
                    disabled={!isEditing}
                    type="email"
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '&.Mui-focused fieldset': {
                          borderColor: '#ADD8E6',
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" component="label">
                    Company
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    value={profile.company}
                    onChange={handleChange('company')}
                    disabled={!isEditing}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '&.Mui-focused fieldset': {
                          borderColor: '#ADD8E6',
                        },
                      },
                    }}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="body2" component="label">
                    Phone
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    value={profile.phone}
                    onChange={handleChange('phone')}
                    disabled={!isEditing}
                    sx={{
                      '& .MuiOutlinedInput-root': {
                        '&.Mui-focused fieldset': {
                          borderColor: '#ADD8E6',
                        },
                      },
                    }}
                  />
                </Grid>
              </Grid>

              <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
                {isEditing ? (
                  <>
                    <Button 
                      onClick={() => setIsEditing(false)} 
                      sx={{ 
                        mr: 1,
                        bgcolor: '#59819B',
                        color: '#FFFFFF',
                        '&:hover': {
                          bgcolor: '#59819B',
                        }
                      }}
                    >
                      Cancel
                    </Button>
                    <Button 
                      variant="contained" 
                      onClick={handleSubmit}
                      disabled={true}
                      sx={{ 
                        bgcolor: '#59819B',
                        color: '#FFFFFF',
                        '&:hover': {
                          bgcolor: '#59819B',
                        }
                      }}
                    >
                      Save
                    </Button>
                  </>
                ) : (
                  <Button 
                    variant="contained" 
                    onClick={() => setIsEditing(true)}
                    disabled={true}
                    sx={{ 
                      bgcolor: '#59819B',
                      color: '#FFFFFF',
                      '&:hover': {
                        bgcolor: '#59819B',
                      }
                    }}
                  >
                    Save
                  </Button>
                )}
              </Box>
            </CardContent>
          </Card>
        </Box>
      </div>
    </div>
  );
};

export default Profile;
