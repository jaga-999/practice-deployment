import { RouteObject, Navigate, useRoutes } from 'react-router-dom';
import Home from '../components/Home';
import NutritionFactsCustomization from '../components/NutritionFactsCustomization';
import Login from '../components/Login';
import RegisterPage from '../components/Register';
import Templates from '../components/Templates';
import { useAuth } from '../context/AuthContext';
import Profile from '../components/Profile';

// Protected Route wrapper component
const ProtectedRoute = ({ children }: { children: JSX.Element }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <div>Loading...</div>; // Replace with your loading component
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

const routes: RouteObject[] = [
  {
    path: '/',
    element: <Navigate to="/home" replace />,
    index: true,
  },
  {
    path: '/home',
    element: (
      <ProtectedRoute>
        <Home />
      </ProtectedRoute>
    ),
  },
  {
    path: '/login',
    element: <Login />,
  },
  {
    path: '/create-label',
    element: (
      <ProtectedRoute>
        <NutritionFactsCustomization />
      </ProtectedRoute>
    ),
  },
  {
    path: '/view-label',
    element: (
      <ProtectedRoute>
        <NutritionFactsCustomization />
      </ProtectedRoute>
    ),
  },
  {
    path: '/profile',
    element: (
      <ProtectedRoute>
        <Profile />
      </ProtectedRoute>
    ),
  },
  {
    path: '/register',
    element: <RegisterPage />,
  },
  {
    path: '/templates',
    element: (
      <ProtectedRoute>
        <Templates />
      </ProtectedRoute>
    ),
  },
  {
    path: '*',
    element: <Navigate to="/login" replace />,
  },
];

export const AppRoutes = () => {
  const element = useRoutes(routes);
  return element;
}; 