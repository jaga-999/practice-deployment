import React, { createContext, useState, useContext, useEffect } from 'react';
import { verifyToken, logout as logoutApi } from '../api/auth.api';
import { useNavigate } from 'react-router-dom';

interface AuthContextType {
  isAuthenticated: boolean;
  user: any | null;
  loading: boolean;
  logout: () => void;
  verifyAuthentication: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  user: null,
  loading: true,
  logout: () => {},
  verifyAuthentication: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const verifyAuthentication = async () => {
    try {
      const response = await verifyToken();
      if (response.status === 'success') {
        setIsAuthenticated(true);
        setUser(response.data?.user);
        
        // Update session storage if needed
        const storedUser = sessionStorage.getItem('user');
        if (storedUser) {
          sessionStorage.setItem('user', JSON.stringify(response.data?.user));
        }
        
        // Navigate to home page on successful verification
        navigate('/');
      } else {
        setIsAuthenticated(false);
        setUser(null);
        sessionStorage.removeItem('user');
      }
    } catch (error) {
      setIsAuthenticated(false);
      setUser(null);
      sessionStorage.removeItem('user');
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await logoutApi();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Clear local state regardless of API success/failure
      setIsAuthenticated(false);
      setUser(null);
      sessionStorage.removeItem('user');
      navigate('/login');
    }
  };

  useEffect(() => {
    verifyAuthentication();
  }, []);

  return (
    <AuthContext.Provider value={{ 
      isAuthenticated, 
      user, 
      loading, 
      logout,
      verifyAuthentication 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext); 