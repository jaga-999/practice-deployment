// Generic JSON value type that can represent any valid JSON value
export type JSONValue = 
  | string
  | number
  | boolean
  | null
  | JSONValue[]
  | { [key: string]: JSONValue };

export interface CreateLabelRequest {
  title: string;
  content: JSONValue;  // This can be any valid JSON structure
}

export interface Label extends CreateLabelRequest {
  _id: string;
  labelId: number;
  title: string;
  content: JSONValue;
  createdBy: User;
  createdDate: string;
  updatedBy?: User;
  updatedDate?: string;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
  __v: number;
}

export interface GetLabelsParams {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PaginatedLabelsResponse {
  labels: Label[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
}

export interface User {
  _id: string;
  userId: string;
  firstName: string;
  lastName: string;
  email: string;
}

export interface LabelDetailsResponse {
  status: string;
  message: string;
  data: Label[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

export interface SingleLabelResponse {
  status: string;
  message: string;
  data: Label;  // Note: This is a single Label object, not an array
}

export interface UpdateLabelRequest {
  labelId: string | number;
  title?: string;
  content?: JSONValue;
}

export interface UpdateLabelResponse {
  status: string;
  message: string;
  data: Label;
}

// Add this new interface for delete response
export interface DeleteLabelResponse {
  status: string;
  message: string;
  data: Label;
}


