export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  firstName: string;
  lastName: string;
}

export interface RegisterResponse {
  status: string;
  message: string;
  data?: {
    userId: string;
    firstName: string;
    lastName: string;
    email: string;
    createdDate: string;
    _id: string;
    createdAt: string;
    updatedAt: string;
    __v: number;
    id: string;
  };
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  status: string;
  message: string;
  data?: {
    user: {
      _id: string;
      userId: string;
      firstName: string;
      lastName: string;
      email: string;
      createdDate: string;
      createdAt: string;
      updatedAt: string;
      __v: number;
      id: string;
    };
  };
}

export interface VerifyTokenResponse {
  status: string;
  message: string;
  data?: {
    user: {
      _id: string;
      userId: string;
      firstName: string;
      lastName: string;
      email: string;
      createdDate: string;
      createdAt: string;
      updatedAt: string;
      __v: number;
      id: string;
    };
  };
} 